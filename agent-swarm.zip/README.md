# 🤖 Agent Swarm - Production Ready

نظام ذكاء اصطناعي متعدد الوكلاء (Multi-Agent AI System) مع نظام Self-Healing وطبقة تفكير ذاتية.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Agent Swarm System                     │
├─────────────────────────────────────────────────────────────┤
│  Infrastructure: NATS (Messaging) | Redis (Cache/Memory)     │
│                  PostgreSQL (Database)                      │
├─────────────────────────────────────────────────────────────┤
│  Core: Orchestrator | Key Manager | Healing Core           │
│        ├─ SystemMonitor (Failure Detection)                │
│        ├─ RecoveryManager (Auto-Restart)                   │
│        └─ CircuitBreaker (Fault Tolerance)                 │
├─────────────────────────────────────────────────────────────┤
│  9 Specialized Agents:                                     │
│  ├─ 🤔 Planner    - Task decomposition & scheduling        │
│  ├─ ⚙️ Tech      - Technical analysis & architecture        │
│  ├─ ✍️ Writer    - Content creation & documentation        │
│  ├─ 🔍 Reviewer  - Quality assurance & feedback           │
│  ├─ 📊 Research  - Data gathering & insights               │
│  ├─ 🎨 Design    - UI/UX & visual design                   │
│  ├─ 📢 Marketing - Campaigns, SEO & social media           │
│  ├─ 🧪 QA        - Testing & bug detection                 │
│  └─ 🚀 DevOps    - Deployment & CI/CD                      │
├─────────────────────────────────────────────────────────────┤
│  Features: Self-Healing | Thinking Layer | Self-Learning   │
│            Memory (Redis) | Health Checks | Circuit Breaker │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- 4GB+ RAM

### Run Everything
```bash
# Clone & enter directory
cd agent-swarm

# Build & start all services
docker-compose up --build

# Or run in background
docker-compose up --build -d
```

### Verify Services
```bash
# Check all containers
docker-compose ps

# View logs
docker-compose logs -f orchestrator
docker-compose logs -f planner-agent

# Health checks
curl http://localhost:8000/health   # Orchestrator
curl http://localhost:8020/health   # Planner Agent
curl http://localhost:8021/health   # Tech Agent
# ... (8020-8028 for all 9 agents)
```

## 📡 API Endpoints

### Orchestrator (Port 8000)
- `GET /health` - Health status

### Key Manager (Port 8001)
- `POST /keys/generate` - Generate API key
- `POST /keys/validate` - Validate API key

### Agents (Ports 8020-8028)
- `GET /health` - Agent health
- `GET /stats` - Agent performance stats

## 🔧 Self-Healing System

### How It Works
1. **SystemMonitor** listens to `agent.error` events
2. After 3 failures, triggers `system.recover` event
3. **RecoveryManager** restarts the failed container
4. **CircuitBreaker** prevents cascade failures

### Manual Recovery
```bash
# Restart a specific agent
docker-compose restart tech-agent

# View healing logs
docker-compose logs -f orchestrator | grep "recover"
```

## 🧠 Thinking Layer

Each agent has a `ThinkingEngine` that:
- **Analyzes** the task type and history
- **Chooses** the best strategy (default/analytical/creative/adaptive/enhanced)
- **Learns** from results to improve future performance
- **Remembers** up to 100 task history + 500 agent memories in Redis

## 📊 Ports Overview

| Service | Port | Description |
|---------|------|-------------|
| Orchestrator | 8000 | Task routing & healing |
| Key Manager | 8001 | API key management |
| NATS | 4222 | Messaging |
| NATS Monitoring | 8222 | NATS dashboard |
| Redis | 6379 | Cache & memory |
| PostgreSQL | 5432 | Database |
| Planner Agent | 8020 | Task planning |
| Tech Agent | 8021 | Technical tasks |
| Writer Agent | 8022 | Content writing |
| Reviewer Agent | 8023 | Quality review |
| Research Agent | 8024 | Research tasks |
| Design Agent | 8025 | Design tasks |
| Marketing Agent | 8026 | Marketing tasks |
| QA Agent | 8027 | Quality assurance |
| DevOps Agent | 8028 | DevOps tasks |

## 🛠️ Development

### Add a New Agent
1. Create folder in `agents/new-agent/`
2. Copy structure from existing agent
3. Update `docker-compose.yml`
4. Add port mapping

### Testing
```bash
# Send a test task via NATS
nats pub task.created '{"id":"test-1","type":"technical"}'

# Monitor task completion
nats sub task.completed
```

## 📄 License
MIT License - Ready for production deployment!
