from fastapi import FastAPI
import nats
import redis.asyncio as redis
import os
import json
import time

app = FastAPI()
nc = None
r = None

@app.on_event("startup")
async def startup():
    global nc, r
    nc = await nats.connect(os.getenv("NATS_URL", "nats://nats:4222"))
    r = await redis.from_url(os.getenv("REDIS_URL", "redis://redis:6379"))

    async def handler(msg):
        data = json.loads(msg.data.decode())
        quality = data.get("quality", 1)
        if quality < 0.6:
            # إعادة إرسال المهمة بذكاء
            await nc.publish("task.created", json.dumps({
                "id": data["task_id"],
                "retry": True,
                "strategy": "enhanced"
            }).encode())

    await nc.subscribe("task.completed", cb=handler)

    # مراقبة Self-Healing
    async def recover_handler(msg):
        data = json.loads(msg.data.decode())
        if data["action"] == "restart":
            await nc.publish("task.created", json.dumps({
                "id": f"recovered-{time.time()}",
                "retry": True,
                "reason": "auto-heal"
            }).encode())

    await nc.subscribe("system.recover", cb=recover_handler)

@app.get("/health")
async def health():
    return {"status": "orchestrator-online"}
