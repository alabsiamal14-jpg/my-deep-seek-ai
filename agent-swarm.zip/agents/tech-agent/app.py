from fastapi import FastAPI
import nats
import redis.asyncio as redis
import json
import os
import time
import sys

# إضافة المسار المشترك
sys.path.insert(0, "/app/common")
from thinking import ThinkingEngine

app = FastAPI()
nc = None
r = None
thinker = None
agent_name = "tech-agent"
expertise = "technical analysis, code review, architecture"

@app.on_event("startup")
async def startup():
    global nc, r, thinker
    nc = await nats.connect(os.getenv("NATS_URL", "nats://nats:4222"))
    r = await redis.from_url(os.getenv("REDIS_URL", "redis://redis:6379"))
    thinker = ThinkingEngine(r)

    async def handler(msg):
        task = json.loads(msg.data.decode())
        try:
            # طبقة التفكير
            task = await thinker.think(task)

            # معالجة المهمة (محاكاة)
            result = f"[tech-agent] Processed task {task['id']} using {task['thinking']['strategy']} strategy"
            quality = task["thinking"]["confidence"]

            # التعلم الذاتي
            await thinker.learn(task["id"], result, quality, agent_name)

            # إرسال النتيجة
            await nc.publish("task.completed", json.dumps({
                "task_id": task["id"],
                "agent": agent_name,
                "result": result,
                "quality": quality,
                "strategy": task["thinking"]["strategy"]
            }).encode())

            # إرسال حالة صحية
            await nc.publish("agent.health", json.dumps({
                "agent": agent_name,
                "status": "healthy"
            }).encode())

        except Exception as e:
            await nc.publish("agent.error", json.dumps({
                "agent": agent_name,
                "error": str(e),
                "task_id": task.get("id")
            }).encode())

    await nc.subscribe("task.created", cb=handler)
    print(f"🤖 {agent_name} started on port 8021 | Expertise: {expertise}")

@app.get("/health")
async def health():
    await nc.publish("agent.health", json.dumps({"agent": agent_name}).encode())
    return {
        "status": f"{agent_name}-online",
        "expertise": expertise,
        "port": 8021
    }

@app.get("/stats")
async def stats():
    stats_data = await r.hgetall(f"stats:{agent_name}")
    return {
        "agent": agent_name,
        "stats": {k.decode(): v.decode() for k, v in stats_data.items()} if stats_data else {}
    }
