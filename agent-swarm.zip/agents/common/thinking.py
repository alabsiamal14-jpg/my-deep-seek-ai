import json
import time

class ThinkingEngine:
    def __init__(self, redis_client):
        self.r = redis_client

    async def think(self, task):
        """
        طبقة التفكير: تحليل المهمة واختيار الاستراتيجية الأفضل
        """
        task_id = task["id"]
        history_key = f"history:{task_id}"

        # جلب التاريخ
        history = await self.r.lrange(history_key, 0, -1)
        history = [json.loads(h) for h in history]

        # اختيار الاستراتيجية بناءً على التاريخ والمهمة
        strategy = self._choose_strategy(task, history)

        task["thinking"] = {
            "strategy": strategy,
            "confidence": self._calculate_confidence(history),
            "timestamp": time.time()
        }

        return task

    def _choose_strategy(self, task, history):
        """اختيار الاستراتيجية بناءً على نوع المهمة"""
        task_type = task.get("type", "default")
        retry = task.get("retry", False)

        if retry:
            return "enhanced"
        if task_type in ["code", "technical"]:
            return "analytical"
        if task_type in ["creative", "design"]:
            return "creative"
        if len(history) > 5:
            return "adaptive"
        return "default"

    def _calculate_confidence(self, history):
        """حساب مستوى الثقة بناءً على التاريخ"""
        if not history:
            return 0.5
        successes = sum(1 for h in history if h.get("quality", 0) > 0.7)
        return min(0.95, successes / len(history))

    async def learn(self, task_id, result, quality, agent_name):
        """
        تعلم ذاتي: حفظ النتيجة لتحسين الأداء المستقبلي
        """
        history_key = f"history:{task_id}"
        memory_key = f"memory:{agent_name}"

        entry = {
            "result": result,
            "quality": quality,
            "timestamp": time.time()
        }

        # حفظ في التاريخ
        await self.r.lpush(history_key, json.dumps(entry))
        await self.r.ltrim(history_key, 0, 99)  # الاحتفاظ بآخر 100

        # حفظ في الذاكرة العامة للوكيل
        await self.r.lpush(memory_key, json.dumps(entry))
        await self.r.ltrim(memory_key, 0, 499)  # الاحتفاظ بآخر 500

        # تحديث إحصائيات الأداء
        await self.r.hincrby(f"stats:{agent_name}", "total_tasks", 1)
        await self.r.hincrbyfloat(f"stats:{agent_name}", "total_quality", quality)
