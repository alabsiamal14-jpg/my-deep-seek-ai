from fastapi import FastAPI, HTTPException
import redis.asyncio as redis
import os
import json
import secrets
import hashlib

app = FastAPI()
r = None

@app.on_event("startup")
async def startup():
    global r
    r = await redis.from_url(os.getenv("REDIS_URL", "redis://redis:6379"))

@app.post("/keys/generate")
async def generate_key(user_id: str, tier: str = "free"):
    """توليد مفتاح API جديد"""
    raw_key = f"sk_{secrets.token_urlsafe(32)}"
    hashed = hashlib.sha256(raw_key.encode()).hexdigest()

    await r.hset(f"key:{hashed}", mapping={
        "user_id": user_id,
        "tier": tier,
        "created_at": str(time.time()),
        "requests_count": 0
    })
    await r.sadd(f"user_keys:{user_id}", hashed)

    return {"api_key": raw_key, "tier": tier}

@app.post("/keys/validate")
async def validate_key(api_key: str):
    """التحقق من صلاحية المفتاح"""
    hashed = hashlib.sha256(api_key.encode()).hexdigest()
    key_data = await r.hgetall(f"key:{hashed}")

    if not key_data:
        raise HTTPException(status_code=401, detail="Invalid API key")

    await r.hincrby(f"key:{hashed}", "requests_count", 1)
    return {"valid": True, "tier": key_data.get(b"tier", b"free").decode()}

@app.get("/health")
async def health():
    return {"status": "key-manager-online"}

import time
