import time
import asyncio

class CircuitBreaker:
    def __init__(self, threshold=3, timeout=10):
        self.threshold = threshold
        self.timeout = timeout
        self.failures = {}
        self.blocked_until = {}

    def allow(self, service):
        if service in self.blocked_until:
            if time.time() < self.blocked_until[service]:
                return False
            else:
                del self.blocked_until[service]
        return True

    def record_failure(self, service):
        self.failures[service] = self.failures.get(service, 0) + 1
        if self.failures[service] >= self.threshold:
            self.blocked_until[service] = time.time() + self.timeout
            self.failures[service] = 0

    def record_success(self, service):
        if service in self.failures:
            del self.failures[service]
