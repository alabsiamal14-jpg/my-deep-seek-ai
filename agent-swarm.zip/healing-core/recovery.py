import docker
import os

class RecoveryManager:
    def __init__(self):
        self.client = docker.from_env()

    def restart_container(self, container_name):
        try:
            container = self.client.containers.get(container_name)
            container.restart()
            return True
        except Exception as e:
            print("Recovery failed:", e)
            return False

    def get_container_logs(self, container_name, tail=50):
        try:
            container = self.client.containers.get(container_name)
            return container.logs(tail=tail).decode()
        except Exception as e:
            return f"Failed to get logs: {e}"
