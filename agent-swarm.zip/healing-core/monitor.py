import asyncio
import nats
import json

class SystemMonitor:
    def __init__(self, nc):
        self.nc = nc
        self.failures = {}

    async def start(self):
        await self.nc.subscribe("agent.error", cb=self.handle_error)
        await self.nc.subscribe("agent.health", cb=self.handle_health)

    async def handle_error(self, msg):
        data = json.loads(msg.data.decode())
        agent = data["agent"]

        self.failures[agent] = self.failures.get(agent, 0) + 1
        if self.failures[agent] >= 3:
            await self.nc.publish("system.recover", json.dumps({
                "agent": agent,
                "action": "restart"
            }).encode())

    async def handle_health(self, msg):
        data = json.loads(msg.data.decode())
        agent = data["agent"]
        self.failures[agent] = 0
